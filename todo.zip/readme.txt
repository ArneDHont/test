Todolist Sample Site
===================

How to install
--------------
* import todo.sql
* check/adjust DB settings in includes/config.php


Testaccounts
------------
* two testaccounts are provided in the .sql dump
- bramus:Azerty123
- rogier:Azerty123


(c) 2011-2015 Bramus Van Damme <bramus.vandamme@odisee.be> - IkDoeICT.be